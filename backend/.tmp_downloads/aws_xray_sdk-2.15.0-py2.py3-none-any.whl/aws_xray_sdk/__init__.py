from .sdk_config import SDKConfig

global_sdk_config = SDKConfig()
