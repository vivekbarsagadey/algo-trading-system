from __future__ import annotations


class FatalError(RuntimeError):
    pass
